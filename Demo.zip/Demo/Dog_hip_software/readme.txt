heart_analysis Executable

1. Prerequisites for Deployment 

Download and install the Windows version of the MATLAB Runtime for R2022a (9.12)
from the following link on the MathWorks website:

    https://www.mathworks.com/products/compiler/mcr/index.html
   


2. In the dog hip analysis software:

================================
-heart_analysis.exe







